import requests
from bs4 import BeautifulSoup

class JobScraper:
    def __init__(self, company_name):
        self.company_name = company_name
        self.base_url = "https://www.hcltech.com/en-br/careers"

    def fetch_jobs(self):
        headers = {
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64)"
        }
        
        response = requests.get(self.base_url, headers=headers)

        if response.status_code != 200:
            print(f"Failed to fetch jobs: Status code {response.status_code}")
            return []

        soup = BeautifulSoup(response.text, "html.parser")
        print("Parsing job listings...",soup
        )

        jobs = []

        # This depends on HCL's website structure.
        # You need to inspect it and extract accordingly.

        # Example (adjust selectors as per real structure):
        job_cards = soup.select(".job-card")   # example class, may vary
        for card in job_cards:
            title = card.select_one(".job-title").text.strip()
            location = card.select_one(".job-location").text.strip()
            posting_date = card.select_one(".job-posted-date").text.strip()

            jobs.append({
                "company": self.company_name,
                "title": title,
                "location": location,
                "posting_date": posting_date
            })

        return jobs

if __name__ == "__main__":
    scraper = JobScraper("HCL")
    job_listings = scraper.fetch_jobs()

    for job in job_listings:
        print(job)
