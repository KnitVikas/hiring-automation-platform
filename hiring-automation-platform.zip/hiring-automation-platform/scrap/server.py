from fastapi import FastAPI
from pydantic import BaseModel
from selenium import webdriver
from selenium.webdriver.chrome.service import Service
# from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.chrome.options import Options
from selenium.common.exceptions import NoSuchElementException
from selenium.webdriver.chrome.service import Service
# from selenium.webdriver.support.ui import WebDriverWait
# from selenium.webdriver.support import expected_conditions as EC
from time import sleep
from random import randint
from webdriver_manager.chrome import ChromeDriverManager
from bs4 import BeautifulSoup
from typing import List, Optional
import json

app = FastAPI()

class ScrapeRequest(BaseModel):
    company_name: Optional[str] = None
    location: Optional[str] = None
    skill: Optional[str] = None
    designation: Optional[str] = None
    start_page: int = 1
    end_page: int = 2


def generate_url(index: int):
    if index == 1:
        return "https://www.naukri.com/software-engineer-jobs-in-india"
    else:
        return f"https://www.naukri.com/machine-learning-engineer-jobs-in-india-{index}"

def extract_rating(rating_a):
    if rating_a is None or rating_a.find('span', class_="main-2") is None:
        return "None"
    else:
        return rating_a.find('span', class_="main-2").text

def parse_job_data_from_soup(page_jobs):
    all_jobs = []
    for job in page_jobs:
        job_details = {"job_title": None, "company_name": None, "rating": None, "experience": None, "location": None, "min_requirements": None, "all_tech_stack": []}
        
        job = BeautifulSoup(str(job), 'html.parser')
        row1 = job.find('div', class_="row1")
        row2 = job.find('div', class_="row2")
        row3 = job.find('div', class_="row3")
        row4 = job.find('div', class_="row4")
        row5 = job.find('div', class_="row5")
        row6 = job.find('div', class_="row6")
        
        job_title = row1.a.text
        company_name = row2.span.a.text
        rating_a = row2.span
        rating = extract_rating(rating_a)
        
        job_details = row3.find('div', class_="job-details")
        ex_wrap = job_details.find('span', class_="exp-wrap").span.span.text
        location = job_details.find('span', class_="loc-wrap ver-line").span.span.text

        min_requirements = row4.span.text

        all_tech_stack = []
        if row5:
            ul_tag = row5.find('ul')
            if ul_tag:
                for tech_stack in ul_tag.find_all('li', class_=["dot-gt", "tag-li"]):
                    all_tech_stack.append(tech_stack.text.strip())

        posted_time = None
        if row6:
            posted_time_span = row6.find('span', class_="Posted")
            if posted_time_span:
                posted_time = posted_time_span.text.strip()
        
        job_details = {
            "job_title": job_title,
            "company_name": company_name,
            "rating": rating,
            "experience": ex_wrap,
            "location": location,
            "min_requirements": min_requirements,
            "all_tech_stack": all_tech_stack,
            "posted_time": posted_time
        }
        all_jobs.append(job_details)

    return all_jobs

def get_driver():
    options = webdriver.ChromeOptions() 
    options.headless = True
    chrome_driver_path = '/home/vikas/.wdm/drivers/chromedriver/linux64/134.0.6998.165/chromedriver-linux64/chromedriver'  # Update with your ChromeDriver path
    driver = webdriver.Chrome(service=Service(chrome_driver_path), options=options)
    return driver

@app.post("/scrape_jobs")
async def scrape_jobs(request: ScrapeRequest):
   

    company_name = request.company_name
    location = request.location
    skill = request.skill
    designation = request.designation
    start_page = request.start_page
    end_page = request.end_page

    flag_url = False
    all_jobs = []

    if company_name:
        if location:
            base_url = f"https://www.naukri.com/{company_name}-jobs-in-{location}-page-"
        else:
            location = "india"
            base_url = f"https://www.naukri.com/{company_name}-jobs-in-{location}-page-"
    elif skill:
        if location:
            base_url = f"https://www.naukri.com/{skill}-jobs-in-{location}-page-"
        else:
            location = "india"
            base_url = f"https://www.naukri.com/{skill}-jobs-in-{location}-page-"
    elif designation:
        if location:
            base_url = f"https://www.naukri.com/{designation}-jobs-in-{location}-page-"
        else:
            location = "india"
            base_url = f"https://www.naukri.com/{designation}-jobs-in-{location}-page-"
    else:
        base_url = "https://www.naukri.com"
        flag_url = True

    try:
        if flag_url:
            for i in range(start_page, end_page):
                url = f"{base_url}{i}"
                driver.get(url)
                sleep(randint(5, 10))
                page_source = driver.page_source
                soup = BeautifulSoup(page_source, 'html.parser')
                page_soup = soup.find_all("div", class_="srp-jobtuple-wrapper")
                jobs = parse_job_data_from_soup(page_soup)
                all_jobs.extend(jobs)
        else:
            for i in range(start_page, end_page):
                final_url = base_url + str(i)
                driver.get(final_url)
                sleep(randint(5, 10))
                page_source = driver.page_source
                soup = BeautifulSoup(page_source, 'html.parser')
                page_soup = soup.find_all("div", class_="srp-jobtuple-wrapper")
                jobs = parse_job_data_from_soup(page_soup)
                all_jobs.extend(jobs)

    except Exception as e:
        return {"error": str(e)}
    finally:
        driver.quit()

    return {"jobs": all_jobs}
