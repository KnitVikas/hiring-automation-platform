def generate_naukri_url(job_title="", company_name="", location="", experience_range="", job_id=""):
    # Base URL structure for Naukri job listings
    base_url = "https://www.naukri.com/job-listings-"
    
    # Format parameters by replacing spaces with hyphens and converting to lowercase
    formatted_title = job_title.replace(" ", "-").lower() if job_title else ""
    formatted_company = company_name.replace(" ", "-").lower() if company_name else ""
    formatted_location = location.replace(" ", "-").lower() if location else ""
    formatted_experience = experience_range.replace(" ", "-").lower() if experience_range else ""
    
    # Construct the URL based on the available parameters
    url_parts = [base_url]
    
    # Add each part if it's not empty
    if formatted_title:
        url_parts.append(formatted_title)
    if formatted_company:
        url_parts.append(formatted_company)
    if formatted_location:
        url_parts.append(formatted_location)
    if formatted_experience:
        url_parts.append(formatted_experience)
    
    # Add job_id at the end of the URL
    if job_id:
        url_parts.append(job_id)
    
    # Join the URL parts and add the query parameters
    url = "-".join(url_parts)
    
    return url

# Example usage with some parameters missing
job_title = ""
company_name = ""
location = "Bengaluru"
experience_range = ""  # Empty experience range
job_id = ""

url = generate_naukri_url(job_title, company_name, location, experience_range, job_id)
print(url)

# Example with more empty parameters
url2 = generate_naukri_url(company_name="Technogen", job_id="260425005568")
print(url2)

# Example with no parameters
url3 = generate_naukri_url()
print(url3)
