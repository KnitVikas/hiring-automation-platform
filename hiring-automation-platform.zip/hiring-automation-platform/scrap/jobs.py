from selenium import webdriver
from datetime import datetime
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.common.keys import Keys
from selenium.common.exceptions import NoSuchElementException
from time import sleep
from random import randint

from selenium.webdriver.chrome.service import Service
from bs4 import BeautifulSoup
from webdriver_manager.chrome import ChromeDriverManager
import json

start_time = datetime.now()
print('Crawl starting time : {}' .format(start_time.time()))
print()


# valid_url = [f"https://www.naukri.com/{company_name}-jobs-in-{location}-page-{index}",
#              f"https://www.naukri.com/{skill}-jobs-in-{location}-page-{index}",
#              f"https://www.naukri.com/{designation}-jobs-in-{location}-page-{index}",]

def generate_url(index):
    if index == 1:
        return "https://www.naukri.com/software-engineer-jobs-in-india"
        # return "https://www.naukri.com/hcl-jobs"
    else:
        return format("https://www.naukri.com/machine-learning-engineer-jobs-in-india-{}".format(index))
    return url

def extract_rating(rating_a):
    if rating_a is None or rating_a.find('span', class_="main-2") is None:
        return "None"
    else:
        return rating_a.find('span', class_="main-2").text
  
def parse_job_data_from_soup(page_jobs):
    print("********PAGE_JOBS***********")
    all_jobs = []
    for job in page_jobs:
        job_details = {"job_title": None, "company_name": None, "rating": None, "experience": None, "location": None, "min_requirements": None, "all_tech_stack": []}
        
        job = BeautifulSoup(str(job), 'html.parser')
        row1 = job.find('div', class_="row1")
        row2 = job.find('div', class_="row2")
        row3 = job.find('div', class_="row3")
        row4 = job.find('div', class_="row4")
        row5 = job.find('div', class_="row5")
        row6 = job.find('div', class_="row6")
        print("*************START***************")
        job_title = row1.a.text
        # print(row2.prettify())
        company_name = row2.span.a.text
        rating_a = row2.span
        rating = extract_rating(rating_a)
        
        job_details = row3.find('div', class_="job-details")
        ex_wrap = job_details.find('span', class_="exp-wrap").span.span.text
        location = job_details.find('span', class_="loc-wrap ver-line").span.span.text

        min_requirements = row4.span.text

        all_tech_stack = []
        if row5:
            ul_tag = row5.find('ul')
            if ul_tag:
                for tech_stack in ul_tag.find_all('li', class_=["dot-gt", "tag-li"]):
                    all_tech_stack.append(tech_stack.text.strip())

        
    # Extract job posting time
        posted_time = None
        if row6:
            posted_time_span = row6.find('span', class_="Posted")
            if posted_time_span:
                posted_time = posted_time_span.text.strip()
        
        job_details={"job_title": job_title, "company_name": company_name, "rating": rating, "experience": ex_wrap, "location": location, "min_requirements": min_requirements, "all_tech_stack": all_tech_stack, "posted_time": posted_time}
        all_jobs.append(job_details)




        # print("Job Title : {}" .format(job_title))
        # print("Company Name : {}" .format(company_name))
        # print("Rating : {}" .format(rating))
        # print("Experience : {}" .format(ex_wrap))
        # print("Location : {}" .format(location))
        # print("Minimum Requirements : {}" .format(min_requirements))
        # print("All Tech Stack : {}" .format(all_tech_stack))

    #     print("***************END***************")
    # print("********PAGE_JOBS END***********")
    return all_jobs


options = webdriver.ChromeOptions() 
options.headless = True 
# driver=webdriver.Chrome(service=Service(ChromeDriverManager().install()), options=options)
# Manually point to the correct executable file
chrome_driver_path = '/home/vikas/.wdm/drivers/chromedriver/linux64/134.0.6998.165/chromedriver-linux64/chromedriver'

driver = webdriver.Chrome(service=Service(chrome_driver_path), options=options)



flag_url = False
start_page = 1
page_end = 2

company_name = "hcl"
location = "bengaluru"
skill = None
designation = None

if company_name:
    if location:
        base_url = f"https://www.naukri.com/{company_name}-jobs-in-{location}-page-"
    else:
        location = "india"
        base_url = f"https://www.naukri.com/{company_name}-jobs-in-{location}-page-"
elif skill:
    if location:
        base_url = f"https://www.naukri.com/{skill}-jobs-in-{location}-page-"
    else:
        location = "india"
        base_url = f"https://www.naukri.com/{skill}-jobs-in-{location}-page-"
elif designation:
    if location:
        base_url = f"https://www.naukri.com/{designation}-jobs-in-{location}-page-"
    else:
        location = "india"
        base_url = f"https://www.naukri.com/{designation}-jobs-in-{location}-page-"
else:
    base_url = f"https://www.naukri.com"
    flag_url = True

all_jobs = []

if flag_url:
    for i in range(start_page, page_end):
        url = f"{base_url}{i}"  # assuming generate_url does something similar
        driver.get(url)
        sleep(randint(5, 10))
        page_source = driver.page_source
        soup = BeautifulSoup(page_source, 'html.parser')
        page_soup = soup.find_all("div", class_="srp-jobtuple-wrapper")
        jobs = parse_job_data_from_soup(page_soup)
        all_jobs.extend(jobs)
else:
    for i in range(start_page, page_end):
        final_url = base_url + str(i)
        driver.get(final_url)
        sleep(randint(5, 10))
        page_source = driver.page_source
        soup = BeautifulSoup(page_source, 'html.parser')
        page_soup = soup.find_all("div", class_="srp-jobtuple-wrapper")
        jobs = parse_job_data_from_soup(page_soup)
        all_jobs.extend(jobs)

# Now dump the jobs list
json_object = json.dumps(all_jobs, indent=4)
print(json_object)