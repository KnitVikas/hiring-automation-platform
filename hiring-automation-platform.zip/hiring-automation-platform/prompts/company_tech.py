class CompanyPromptGenerator:
    def __init__(self, companies):
        self.companies = companies

    def generate_prompt(self):
        prompt = (
            "For the following companies, please tell me if they hire for tech roles. "
            "If yes, list the headquarters and the tech skills they hire for.\n"
            "Return the answer in the following JSON array format:\n\n"
            "[\n"
            "  {\n"
            "    \"company_name\": \"\",\n"
            "    \"headquarter\": \"\",\n"
            "    \"skills\": []\n"
            "  },\n"
            "  {\n"
            "    \"company_name\": \"\",\n"
            "    \"headquarter\": \"\",\n"
            "    \"skills\": []\n"
            "  }\n"
            "]\n\n"
            "Here are the companies:\n"
        )
        for company in self.companies:
            prompt += f"- {company}\n"
        return prompt

# Example usage:
companies = ["Techila Global Services", "Adidas", "Google"]
generator = CompanyPromptGenerator(companies)
print(generator.generate_prompt())
