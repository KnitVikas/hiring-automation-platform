class Prompt:
    # Class-level variable to store skills


    def __init__(self, quest_to_create):
        self.quest_to_create = quest_to_create
        self.techStack = [entry["techStack"] for entry in self.quest_to_create]
        
        # If the techStack list is empty, initialize it with the input skills
        # if not Prompt.techStack:  
        #     Prompt.techStack = [entry["techStack"] for entry in self.quest_to_create]
        
        # Prepare dictionaries for experience levels and number of questions
        self.exp_levels = {entry["techStack"]: entry["expLevel"] for entry in self.quest_to_create}
        self.num_questions = {entry["techStack"]: entry["numOfQuestions"] for entry in self.quest_to_create}
        print("******", self.exp_levels,self.num_questions)
        # Create the prompt
        self.prompt = self.create_prompt()

    def create_prompt(self):
        # Create the prompt with f-strings to include the skills dynamically
        prompt_text = f"""Prompt to Generate Multiple-Choice Questions (MCQs):
                        Generate random and always unique multiple-choice questions (MCQs) for the following topics and experience levels:
                        Skill/Topic: Choose from the following list:
                        """
        
        # Add each skill to the prompt
        for skill in self.techStack:
            prompt_text += f"{skill}\n"
        
        prompt_text += "\nExperience Levels: For each experience level, generate the specified number of questions:\n"
        
        # Add the number of questions for each skill and its experience level
        for skill in self.techStack:
            experience_level = self.exp_levels.get(skill)  # Look up experience level for the skill
            num_questions = self.num_questions.get(skill)  # Get the number of questions, defaulting to 0
            prompt_text += f"\n{skill} ({experience_level}): {num_questions} questions"
        
        prompt_text += """
                                
                        Characteristics of Each MCQ:
                        A clear, concise question that accurately tests knowledge relevant to the skill and experience level.
                        Four answer options (A, B, C, D), with only one correct answer and three plausible distractors.
                        A brief explanation or rationale for the correct answer (with the correct answer listed first) after the question."""

        # Add example MCQs with correct answers listed first
        prompt_text += "\n\nExample MCQs:\n"
        prompt_text += self.get_example_mcqs()

        return prompt_text

    def get_example_mcqs(self):
        # Example MCQs with the correct option first and then the distractors
        example_mcqs = [
            {
                'question': "What is the output of the following Python code: `print(2 + 3)`?",
                'options': ['A) 5', 'B) 23', 'C) 2 + 3', 'D) None'],
                'correct_option': 'A',
                'explanation': "The correct answer is A) 5, as 2 + 3 evaluates to 5 in Python."
            },
            {
                'question': "Which of the following is a Python data structure?",
                'options': ['A) List', 'B) Integer', 'C) String', 'D) Float'],
                'correct_option': 'A',
                'explanation': "The correct answer is A) List, as it is a built-in data structure in Python."
            }
        ]
        
        mcq_text = ""
        for mcq in example_mcqs:
            mcq_text += f"\n{mcq['question']}\n"
            mcq_text += f"Options:\n"
            for option in mcq['options']:
                mcq_text += f"{option}\n"
            mcq_text += f"Explanation: {mcq['explanation']}\n"
       
        mcq_text += """
            Please respond in JSON format as follows:
            {
                "mcqQuestions": [
                    {
                        "skill": "JAVA",
                        "level": "Beginner",
                        "questions": [
                            {
                                "question": "What is Java?",
                                "options": ["A) A programming language", "B) A fruit", "C) A city", "D) A car"],
                                "correct_option": "A",
                                "explanation": "The correct answer is A) A programming language, because Java is a programming language."
                            },
                            {
                                "question": "Which of the following is a Java data structure?",
                                "options": ["A) Array", "B) String", "C) Integer", "D) Float"],
                                "correct_option": "A",
                                "explanation": "The correct answer is A) Array, as it is a built-in data structure in Java."
                            }
                        ]
                    },
                    {
                        "skill": "devops",
                        "level": "Mediator (Intermediate)",
                        "questions": [
                            {
                                "question": "What is Continuous Integration (CI)?",
                                "options": ["A) Integrating code continuously", "B) Deploying code to production", "C) Testing code continuously", "D) Writing documentation"],
                                "correct_option": "A",
                                "explanation": "The correct answer is A) Integrating code continuously, which is the goal of Continuous Integration."
                            }
                        ]
                    }
                ]
            }

            The response should contain a 'questions' field, which is an array of question objects for each skill and experience level. Each question object should include the question text, answer options, correct option, and explanation in the structure provided above."""
            
        return mcq_text

quest = [

    {
      "techStack": "python",
      "expLevel": "easy",
      "numOfQuestions": 5
    },
        {
      "techStack": "python",
      "expLevel": "easy",
      "numOfQuestions": 5
    }
  ]

prompt_obj = Prompt(quest)
print("tthis is final prompt",prompt_obj)
prompt = prompt_obj.prompt
print("tthis is final prompt",prompt)