class JobScrapingPromptBuilder:
    def __init__(
        self,
        country="India",
        platforms=None,
        locations=None,
        skills=None,
        companies=None,
        posted_within=2
    ):
        self.country = country
        self.platforms = platforms or [
            "Naukri.com", "LinkedIn Jobs", "Indeed", "Monster India"
        ]
        self.locations = locations or ["Bangalore", "Hyderabad", "Pune", "Delhi"]
        self.skills = skills or ["Java", "Python", "AWS", "React", "Node.js"]
        self.companies = companies or ["TCS", "Infosys", "Google", "Amazon", "Wipro"]
        self.posted_within = posted_within

    def generate_prompt(self):
            return f"""
            can you provide me recent job postings in India from job portals like Naukri.com, LinkedIn Jobs, Indeed, Monster India, or similar platforms.

            Focus only on jobs that include:
            - Location in India ({", ".join(self.locations)})
            - Technical Skills ({", ".join(self.skills)})
            - Company Names ({", ".join(self.companies)})

            Only include job postings from the last {self.posted_within} months.

            For each job posting, extract and format the data in the Required Response Format (JSON) and  NO PREAMBLE TEXT:

            [
            {{
                "companyName": "<Name of the company>",
                "applyURL": "<Direct link to the job application or job details>",
                "companyEmail": null,
                "headquarter": "<City, Country>",
                "skills": ["Skill1", "Skill2", "..."],
                "payscale": {{
                "low": "<lowest estimated LPA>",
                "medium": "<median estimated LPA>",
                "high": "<highest estimated LPA>"
                }},
                "hrDetails": null
            }}
            ]

            ✅ Only include companies based in or hiring for India.
            ✅ Make sure skills are listed in array format.
            ✅ Keep companyEmail and hrDetails as null if not available.
            ✅ Include pay scale estimates if available in the posting.
            ✅ Include 10–15 job entries in the response.
            """








builder = JobScrapingPromptBuilder(
    companies=["CRED", "Swiggy", "Zomato"],
    skills=["Kubernetes", "Golang", "PostgreSQL"],
    platforms=["LinkedIn Jobs", "Instahyre", "Naukri.com"],
    posted_within="last 45 days"
)


builder = JobScrapingPromptBuilder(
    companies=["Optum", "Infogain", "Zoho"],
    locations=["Hyderabad", "Noida", "Chennai"],
    posted_within="past 30 days"
)
prompt = builder.generate_prompt()
print(prompt)

