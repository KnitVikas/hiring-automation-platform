class ResumeParsingPrompt:
    def __init__(self, resume_text):
        self.resume_text = resume_text
        self.json_template = {
            "ResumeParserData": {
                "ResumeFileName": "",
                "ResumeLanguage": {
                    "Language": "",
                    "LanguageCode": ""
                },
                "ParsingDate": "",
                "ResumeCountry": {
                    "Country": "",
                    "Evidence": "",
                    "CountryCode": {
                        "IsoAlpha2": "",
                        "IsoAlpha3": "",
                        "UNCode": ""
                    }
                },
                "Name": {
                    "FullName": "",
                    "TitleName": "",
                    "FirstName": "",
                    "MiddleName": "",
                    "LastName": "",
                    "FormattedName": "",
                    "ConfidenceScore": 0
                },
                "DateOfBirth": "",
                "Gender": "",
                "FatherName": "",
                "MotherName": "",
                "MaritalStatus": "",
                "Nationality": "",
                "LanguageKnown": [
                    {
                        "Language": "",
                        "LanguageCode": ""
                    }
                ],
                "UniqueID": "",
                "LicenseNo": "",
                "PassportDetail": {
                    "PassportNumber": "",
                    "DateOfExpiry": "",
                    "DateOfIssue": "",
                    "PlaceOfIssue": ""
                },
                "PanNo": "",
                "VisaStatus": "",
                "Email": [
                    {
                        "EmailAddress": "",
                        "ConfidenceScore": 0
                    }
                ],
                "PhoneNumber": [
                    {
                        "Number": "",
                        "ISDCode": "",
                        "OriginalNumber": "",
                        "FormattedNumber": "",
                        "Type": "",
                        "ConfidenceScore": 0
                    }
                ],
                "WebSite": [
                    {
                        "Type": "",
                        "Url": ""
                    }
                ],
                "Address": [
                    {
                        "Street": "",
                        "City": "",
                        "State": "",
                        "StateIsoCode": "",
                        "Country": "",
                        "CountryCode": {
                            "IsoAlpha2": "",
                            "IsoAlpha3": "",
                            "UNCode": ""
                        },
                        "ZipCode": "",
                        "FormattedAddress": "",
                        "Type": "",
                        "ConfidenceScore": 0
                    }
                ],
                "Category": "",
                "SubCategory": "",
                "CurrentSalary": {
                    "Amount": "",
                    "Symbol": "",
                    "Currency": "",
                    "Unit": "",
                    "Text": ""
                },
                "ExpectedSalary": {
                    "Amount": "",
                    "Symbol": "",
                    "Currency": "",
                    "Unit": "",
                    "Text": ""
                },
                "Qualification": "",
                "SegregatedQualification": [
                    {
                        "Institution": {
                            "Name": "",
                            "Type": "",
                            "ConfidenceScore": 0,
                            "Location": {
                                "City": "",
                                "State": "",
                                "StateIsoCode": "",
                                "Country": "",
                                "CountryCode": {
                                    "IsoAlpha2": "",
                                    "IsoAlpha3": "",
                                    "UNCode": ""
                                }
                            }
                        },
                        "Degree": {
                            "DegreeName": "",
                            "NormalizeDegree": "",
                            "Specialization": [],
                            "ConfidenceScore": 0
                        },
                        "FormattedDegreePeriod": "",
                        "StartDate": "",
                        "EndDate": "",
                        "Aggregate": {
                            "Value": "",
                            "MeasureType": ""
                        }
                    }
                ],
                "Certification": "",
                "SegregatedCertification": [
                    {
                        "CertificationTitle": "",
                        "Authority": "",
                        "CertificationCode": "",
                        "IsExpiry": "",
                        "StartDate": "",
                        "EndDate": "",
                        "CertificationUrl": ""
                    }
                ],
                "SkillBlock": "",
                "SkillKeywords": "",
                "SegregatedSkill": [
                    {
                        "Type": "",
                        "Skill": "",
                        "Ontology": "",
                        "Alias": "",
                        "FormattedName": "",
                        "Evidence": "",
                        "LastUsed": "",
                        "ExperienceInMonths": 0
                    }
                ],
                "Experience": "",
                "SegregatedExperience": [
                    {
                        "Employer": {
                            "EmployerName": "",
                            "FormattedName": "",
                            "ConfidenceScore": 0
                        },
                        "JobProfile": {
                            "Title": "",
                            "FormattedName": "",
                            "Alias": "",
                            "RelatedSkills": [
                                {
                                    "Skill": "",
                                    "ProficiencyLevel": ""
                                }
                            ],
                            "ConfidenceScore": 0
                        },
                        "Location": {
                            "City": "",
                            "State": "",
                            "StateIsoCode": "",
                            "Country": "",
                            "CountryCode": {
                                "IsoAlpha2": "",
                                "IsoAlpha3": "",
                                "UNCode": ""
                            }
                        },
                        "JobPeriod": "",
                        "FormattedJobPeriod": "",
                        "StartDate": "",
                        "EndDate": "",
                        "IsCurrentEmployer": "",
                        "JobDescription": "",
                        "Projects": [
                            {
                                "UsedSkills": "",
                                "ProjectName": "",
                                "TeamSize": ""
                            }
                        ]
                    }
                ],
                "CurrentEmployer": "",
                "JobProfile": "",
                "WorkedPeriod": {
                    "TotalExperienceInMonths": "",
                    "TotalExperienceInYear": "",
                    "TotalExperienceRange": ""
                },
                "GapPeriod": "",
                "AverageStay": "",
                "LongestStay": "",
                "Summary": "",
                "ExecutiveSummary": "",
                "ManagementSummary": "",
                "Coverletter": "",
                "Publication": "",
                "SegregatedPublication": [
                    {
                        "PublicationTitle": "",
                        "Publisher": "",
                        "PublicationNumber": "",
                        "PublicationUrl": "",
                        "Authors": "",
                        "Description": ""
                    }
                ],
                "CurrentLocation": [
                    {
                        "City": "",
                        "State": "",
                        "StateIsoCode": "",
                        "Country": "",
                        "CountryCode": {
                            "IsoAlpha2": "",
                            "IsoAlpha3": "",
                            "UNCode": ""
                        }
                    }
                ],
                "PreferredLocation": [
                    {
                        "City": "",
                        "State": "",
                        "StateIsoCode": "",
                        "Country": "",
                        "CountryCode": {
                            "IsoAlpha2": "",
                            "IsoAlpha3": "",
                            "UNCode": ""
                        }
                    }
                ],
                "Availability": "",
                "Hobbies": "",
                "Objectives": "",
                "Achievements": "",
                "SegregatedAchievement": [
                    {
                        "AwardTitle": "",
                        "Issuer": "",
                        "AssociatedWith": "",
                        "IssuingDate": "",
                        "Description": ""
                    }
                ],
                "References": "",
                "CustomFields": "",
                "EmailInfo": {
                    "EmailTo": "",
                    "EmailBody": "",
                    "EmailReplyTo": "",
                    "EmailSignature": "",
                    "EmailFrom": "",
                    "EmailSubject": "",
                    "EmailCC": ""
                },
                "Recommendations": [
                    {
                        "PersonName": "",
                        "CompanyName": "",
                        "Relation": "",
                        "PositionTitle": "",
                        "Description": ""
                    }
                ],
                "DetailResume": "",
                "CandidateImage": {
                    "CandidateImageData": "",
                    "CandidateImageFormat": ""
                },
                "TemplateOutput": {
                    "TemplateOutputFileName": "",
                    "TemplateOutputData": ""
                },
                "ApiInfo": {
                    "Metered": "",
                    "CreditLeft": "",
                    "AccountExpiryDate": "",
                    "BuildVersion": ""
                }
            },
            "ResumeQuality": [
                {
                    "Level": "",
                    "Findings": [
                        {
                            "QualityCode": "",
                            "SectionIdentifiers": [
                                {
                                    "SectionType": "",
                                    "Id": ""
                                }
                            ],
                            "Message": ""
                        }
                    ]
                }
            ]
        }

    def get_prompt(self):
        return f"""
        Extract structured information from the resume text and return a JSON output **exactly** matching this format.

        ### Resume Text:
        {self.resume_text}

        ### JSON Output Format:
        {self.json_template}

        Please ensure that:

        - The **name** fields are correctly extracted (e.g., FirstName, LastName, etc.).
        - The **email** and **phone number** details are captured properly.
        - Each **qualification**, **experience**, **skill**, and **certification** is mapped accurately with the right fields.
        - **Job titles** and **employer names** are extracted and mapped to the correct sections.
        - **Dates** of employment, qualifications, and certifications are captured in the right format (start/end dates).
        - **Location** details (both current and preferred locations) are mapped to the correct fields including **CountryCode**.
        - **Publications**, **Achievements**, **Hobbies**, **References**, etc. are captured and mapped to their respective fields.
        - Extract any other available details and map them under the appropriate sections.

        Ensure that all sections from the provided template are populated correctly, leaving no fields empty unless the information is missing from the resume text.
        """
