import json
from typing import List, Dict

class CodeEvaluatorPromptGenerator:
    def __init__(self, input_data: Dict):
        """
        Initialize with input data containing code solutions and their questions.
        
        Args:
            input_data (Dict): Expected format:
                {
                    "uploadedCode": [
                        {
                            "answer": "code string", 
                            "question": "original question"
                        },
                        ...
                    ],
                    "parser_type": "chatgpt"|"other"
                }
        """
        self.uploaded_code = input_data["uploadedCode"]
        self.parser_type = input_data["parser_type"]

    def generate_combined_prompt(self) -> Dict:
        """
        Generate a single evaluation prompt for all code-question pairs.
        
        Returns:
            Dict: Contains:
                {
                    "evaluation_prompt": str,
                    "items": List of original questions and code solutions
                }
        """
        prompt_intro = """
        As an expert code reviewer, evaluate these solutions for their respective problems.
        For each solution, provide an evaluation based on the criteria below.
        """.strip()

        evaluation_criteria = """
        Evaluation Criteria (for each solution):
        1. Correctness (5pts): Does it solve the problem correctly?
        2. Readability (5pts): Is the code clean and understandable?
        3. Efficiency (5pts): Is it optimally implemented?
        4. Robustness (5pts): Does it handle edge cases?
        5. Best Practices (5pts): Does it follow language conventions?
        """.strip()

        response_format = """
        Required Response Format (JSON):
        {
            "evaluations": [
                {
                    "question": "original question 1",
                    "evaluation": {
                        "correctness": {
                            "score": "X/5",
                            "explanation": "Your analysis here"
                        },
                        "readability": {
                            "score": "X/5",
                            "explanation": "Your analysis here"
                        },
                        "efficiency": {
                            "score": "X/5",
                            "explanation": "Your analysis here"
                        },
                        "robustness": {
                            "score": "X/5",
                            "explanation": "Your analysis here"
                        },
                        "bestPractices": {
                            "score": "X/5",
                            "explanation": "Your analysis here"
                        }
                    },
                    "overallFeedback": "Summary and suggestions"
                },
                ... (repeat for each solution)
            ],
            "parserType": "chatgpt"
        }
        """.strip()

        # Build the problems and solutions section
        problems_solutions = []
        for item in self.uploaded_code:
            problems_solutions.append(
                "PROBLEM STATEMENT:\n" + item['question'] + "\n\n" +
                "CODE SOLUTION:\n```javascript\n" + item['answer'] + "\n```"
            )

        separator = "\n\n" + ("-" * 50) + "\n"
        full_prompt = (
            prompt_intro + "\n\n" +
            evaluation_criteria + "\n\n" +
            response_format + "\n\n" +
            "PROBLEMS AND SOLUTIONS TO EVALUATE:" +
            separator +
            separator.join(problems_solutions) +
            "\n" + ("-" * 50)
        ).strip()

        return {
            "evaluation_prompt": full_prompt,
            "items": [{"original_question": item["question"], "code_solution": item["answer"]} 
                     for item in self.uploaded_code]
        }


# Example Usage
# if __name__ == "__main__":
#     input_data = {
#         "uploadedCode": [
#             {
#                 "answer": "function checkOnlyDigits (str) {\r\n    return str;\r\n}",
#                 "question": "Write a function to check if a given string contains only digits."
#             },
#             {
#                 "answer": "function sortArray (arr) {\r\n    return arr.sort();\r\n}",
#                 "question": "Write a function to check if a given array is sorted in descending order."
#             }
#         ],
#         "parser_type": "chatgpt"
#     }

#     generator = CodeEvaluatorPromptGenerator(input_data)
#     combined_prompt = generator.generate_combined_prompt()
    
#     print("Generated Combined Prompt:")
#     print("\n" + "="*50 + "\nCombined Evaluation Prompt")
#     print(combined_prompt["evaluation_prompt"])
    
#     print("\n" + "="*50 + "\nItems being evaluated:")
#     for i, item in enumerate(combined_prompt["items"], 1):
#         print("\nItem #" + str(i))
#         print("Question: " + item['original_question'])
#         print("\nCode:\n" + item['code_solution'])
#     print("\n" + "="*50)