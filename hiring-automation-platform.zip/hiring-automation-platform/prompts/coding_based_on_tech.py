class CodingQuestionGenerator:
    def __init__(self, input_data):
        self.input_data = input_data

    def generate_single_prompt(self):
        prompt_parts = []

        # Initial prompt
        prompt_parts.append("Please generate the following RANDOM coding questions based on the specified difficulty levels and technologies:")

        # Track any tech-specific instruction flags
        tech_specific_instructions = set()

        for item in self.input_data:
            tech = item.get("tech", "").lower()
            question_type = "coding question" if item['questionType'] == "coding" else "question"
            exp_level = item['expLevel']
            no_of_questions = item['noOfQuestion']

            prompt_parts.append(f"- {no_of_questions} {exp_level} difficulty {question_type} in {tech}")
            
            if tech:
                tech_specific_instructions.add(tech)

        # Common instruction
        prompt_parts.append("""
Interpret difficulty levels as follows:
- Easy: Basic concepts with minimal logic.
- Medium: Intermediate problem-solving with real-world patterns or integrations.
- Hard: In-depth algorithmic, architectural, or performance-based problems.

Please ensure the output is in **valid JSON** format with this structure:

{
  "codingQuestions": [
    {
      "question": "Describe the problem clearly...",
      "example": [
        {
          "input": "...",
          "output": "...",
          "explanation": "..."
        }
      ],
      "difficulty": "easy/medium/hard",
      "type": "coding",
      "tech": "<tech used>",
      "constraints": "Any problem constraints or assumptions"
    }
  ]
}
""")

        # Add Salesforce-specific instructions only if needed
        if "salesforce" in tech_specific_instructions:
            prompt_parts.append("""
⚙️ Salesforce-specific requirements (if `tech` is "salesforce"):
- Use Apex, SOQL, Triggers, or Lightning components as relevant.
- Ensure questions are aligned with Salesforce developer tasks.
- Include Salesforce context (e.g., objects like Contact, Account, custom triggers, validations).
- Example:
  - Write an Apex trigger to prevent inserting duplicate Contacts based on email address.
  - Ensure case-insensitive check.
  - Trigger should be bulk-safe and raise error for duplicate.
""")

        # Final note
        prompt_parts.append("Ensure the problems are realistic, relevant to the tech, and have a clear, concise structure.")

        return " ".join(prompt_parts)


input_data = [
    {
        "questionType": "coding",
        "expLevel": "medium",
        "noOfQuestion": 1,
        "tech": "Salesforce"
    },
    {
        "questionType": "coding",
        "expLevel": "easy",
        "noOfQuestion": 1,
        "tech": "Python"
    }
]


# ✅ Instantiate and generate prompt
# generator = CodingQuestionGenerator(input_data)
# generated_prompt = generator.generate_single_prompt()

# print(generated_prompt)
