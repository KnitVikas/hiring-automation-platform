import requests
import json

# Define the base URL for the server
# BASE_URL = "http://13.201.189.29:8000/"  # Replace with the actual server URL
BASE_URL = "http://127.0.0.1:8000/"  

################################################### Resume Parsing ####################################################

# Function to send a POST request to /parse_resume/
def parse_resume(file_path, parser_type="chatgpt"):
    url = f"{BASE_URL}/parse_resume/"
    headers = {
        "accept": "application/json"
    }
    files = {
        "file": open(file_path, "rb")  # Open the file in binary mode
    }
    data = {
        "parser_type": parser_type
    }

    # try:
    response = requests.post(url, files=files, data=data, headers=headers, verify = "server_cert.pem")
    if response.status_code == 200:
        print("POST /parse_resume/ - Success!")
        print("Response:", response.json())
    else:
        print(f"POST /parse_resume/ - Failed with status code {response.status_code}")
        print("Response:", response.text)
    # except requests.exceptions.RequestException as e:
    #     print(f"An error occurred during POST /parse_resume/: {e}")
    # finally:
    #     files["file"].close()  # Close the file after the request


# # Example usage for resume parsing
# resume_file_path = "/data-mount/PARSER/data/Profile-abhishek.pdf"  # Replace with the actual file path
# parse_resume(resume_file_path, parser_type="chatgpt")  # Use "chatgpt" or any other model


# # ################################################### Set MCQ Questions ##################################################

# # URL for the /SetMcqQuestions/ endpoint
mcq_url = f"{BASE_URL}/SetMcqQuestions/"

# Data to be sent in the request for setting MCQ questions
mcq_data ={
  "UploadCode": [
    {
      "techStack": "java",
      "expLevel": "medium",
      "numOfQuestions": 5
    },
    {
      "techStack": "chatgpt",
      "expLevel": "easy",
      "numOfQuestions": 5
    }
  ],
  "parser_type": "chatgpt"
}


print("********************** MCQ questions********************")
# Sending the POST request to the /SetMcqQuestions/ endpoint
mcq_response = requests.post(mcq_url, json=mcq_data,verify=False)

# Checking if the request was successful
if mcq_response.status_code == 200:
    print("Response received successfully from /SetMcqQuestions/")
    print("Response content:", mcq_response.json())
else:
    print(f"Request failed with status code: {mcq_response.status_code}")
    print("Error details:", mcq_response)


# # ################################################### Set Coding Questions ################################################
print("********************** codig questions********************")
# # # URL for the /SetCodingQuestions/ endpoint
coding_url = f"{BASE_URL}/SetCodingQuestions/"

# # Data for the request to set coding questions
coding_input_data ={
  "UploadCode": [
    {
      "questionType": "coding",
      "expLevel": "medium",
      "noOfQuestion": 2,
      "tech": "python"
    },
    {
      "questionType": "coding",
      "expLevel": "easy",
      "noOfQuestion": 2,
      "tech": "SQL"
    }
  ],
  "parser_type": "chatgpt"
}

# Sending the POST request to the /SetCodingQuestions/ endpoint
coding_response = requests.post(coding_url, json=coding_input_data,verify=False)

# Checking if the request was successful
if coding_response.status_code == 200:
    print("Response received successfully from /SetCodingQuestions/")
    print("Response content:", coding_response.json())
else:
    print(f"Request failed with status code: {coding_response.status_code}")
    print("Error details:", coding_response.json())


# ################################################### Evaluate Coding Question ################################################



print("********************** Evaluate coding questions********************")

# # URL for the /evaluateCode endpoint
evaluate_url = f"{BASE_URL}/evaluateCode"
# evaluate_url = "http://127.0.0.1:8000/evaluateCode"  
import requests
import json

# evaluate_url = "http://13.201.189.29:8000/evaluateCode/"

payload = {
    "UploadCode": [
        {
            "answer": "function sum(a, b) { return a + b; }",
            "question": "Write a function to add two numbers"
        },
        {
            "answer": "function isEven(n) { return n % 2 === 0; }",
            "question": "Write a function to check if a number is even"
        }
    ],
    "parser_type": "chatgpt"
}

headers = {
    "Content-Type": "application/json",
    "accept": "application/json"
}

response = requests.post(evaluate_url, json=payload)
print("Status Code:", response.status_code)
print("Response:", response.json())


print("********************** Behaviour Analyze********************")

url = f"{BASE_URL}analyze_interview/"
files = {"video": open("speech.mp4", "rb")}
data = {"transcribe_method": "whisper"}

response = requests.post(url, files=files, data=data)
print(response.json())


# The API endpoint URL
url = BASE_URL+"/generateJobScrapingPrompt/"

# Data to be sent in the POST request
data = {
  "country": "India",
  "platforms": ["Naukri.com", "LinkedIn Jobs", "Indeed"],
  "locations": ["Hyderabad", "Noida", "Chennai"],
  "skills": ["Java", "Python", "AWS", "React"],
  "companies": ["Optum", "Infogain", "Zoho"],
  "posted_within_days": 30
}


# Sending the POST request
response = requests.post(url, json=data)

# Printing the response from the server
if response.status_code == 200:
    print("Response:", response.json())
else:
    print("Failed to get a response. Status code:", response.status_code)


print("********************** Company Tech Stack********************") 
# API endpoint
ENDPOINT = "/companyTechstack/"

# Full URL
url = BASE_URL + ENDPOINT
    # Full URL
url = BASE_URL + ENDPOINT

# Request payload (example companies)
payload = {
    "companies": [
        "Techila Global Services",
        "Adidas",
        "Google",
        "Amazon"
    ]
}

# Headers
headers = {
    "Content-Type": "application/json"
}

# Send POST request
response = requests.post(url, headers=headers, data=json.dumps(payload))

# Print the response
if response.status_code == 200:
    print("Response JSON:")
    print(json.dumps(response.json(), indent=2))
else:
    print(f"Request failed with status code: {response.status_code}")
    print(response.text)



print("**********************scrap jobs********************")

ENDPOINT = "/scrape_jobs/"

# Full URL
url = BASE_URL + ENDPOINT
    # Full URL
url = BASE_URL + ENDPOINT

# Request payload (example companies)
payload = {
  "company_name": "hcl",           # // Optional: Company name to filter the jobs.
  "location": "bengaluru",          #// Optional: Location to filter the jobs.
  "skill": "machine-learning",      #// Optional: Skill to filter the jobs.
  "designation": "software-engineer",# // Optional: Job designation to filter the jobs.
  "start_page": 1,                  #// The starting page number for scraping.
  "end_page": 2                     #// The ending page number for scraping.
}

# Headers
headers = {
    "Content-Type": "application/json"
}

# Send POST request
response = requests.post(url, headers=headers, data=json.dumps(payload))

# Print the response
if response.status_code == 200:

    print(json.dumps(response.json(), indent=2))
else:
    print(f"Request failed with status code: {response.status_code}")
    print(response.text)
