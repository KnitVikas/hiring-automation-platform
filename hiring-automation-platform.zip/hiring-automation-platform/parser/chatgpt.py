import openai
from langchain.chat_models import ChatOpenAI
from langchain.prompts import PromptTemplate
from langchain.chains import LLMChain
import os
import time
API_KEY = "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"
openai.api_key = "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"  # Optional if you've set it in environment variables

os.environ["OPENAI_API_KEY"] = API_KEY
# Set OpenAI API Key (If not set in environment variables)

def interact_with_chatgpt(prompt,chatgpt):
    """Function to interact with ChatGPT via LangChain using the best available model (GPT-4)."""
    # Initialize the ChatOpenAI model (use GPT-4 for best results)
    template = "You are a helpful assistant. Answer the following question: {question}"
    prompt_template = PromptTemplate(input_variables=["question"], template=template)

    # Create the chain for processing the input through the model
    t1 = time.time()
    chain = LLMChain(llm=chatgpt, prompt=prompt_template)

    
    t2 = time.time()
    print("cahin making time : ",(t2-t1))
    response = chain.invoke({"question": prompt}) 
    print("resonse ", response["text"])
    t3 = time.time()
    print("model response time ", (t3-t2))

    return response["text"]
