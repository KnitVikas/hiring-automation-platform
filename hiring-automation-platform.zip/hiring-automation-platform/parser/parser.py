import time
import os
import json
import argparse
from langchain_groq import ChatGroq

# "llama-3.1-70b-versatile"   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
#  "gpt-4"  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

class ResumeParser:
    def __init__(self, model_name= "llama-3.3-70b-versatile", temperature=0.0, max_retries=2):
        """Initialize the model with parameters."""
        self.model_name = model_name
        self.temperature = temperature
        self.max_retries = max_retries
        self.groq_api_key = os.getenv('GROQ_API_KEY', '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')

        # Load the model when the object is created
        self.model = self.load_model()

    def load_model(self):
        """Load the model and measure time taken for loading."""
        start_time = time.time()

        # Initialize the model with the provided parameters
        model = ChatGroq(
            model=self.model_name,
            temperature=self.temperature,
            max_retries=self.max_retries,
            groq_api_key=self.groq_api_key
        )

        end_time = time.time()
        print(f"Model loading time: {end_time - start_time:.2f} seconds")
        return model

    def read_resume_text(self, file_path):
        """Read the resume text from a given file."""
        with open(file_path, 'r') as file:
            return file.read()
    @staticmethod
    def get_model_response(prompt, model):
        """Generate the prompt and invoke the model for the response."""
        start_time = time.time()

        # if len(prompt) == 2:
        response = model.invoke(prompt)
        # elif len(prompt) > 2:
        # stream = model.stream(prompt)
            # response = next(stream)
            # for chunk in stream:
            #     response += chunk

        end_time = time.time()

        print(f"Response time: {end_time - start_time:.2f} seconds")
        return response.content
  
    def parse_response(self, response_content):
        """Try to parse the response as JSON and return it."""
        try:
            parsed_response = json.loads(response_content)
            return parsed_response
        except json.JSONDecodeError:
            print("Failed to decode response as JSON.")
            return None

    def save_json_to_file(self, data, output_file):
        """Save the parsed JSON data to a specified file."""
        # Ensure the output directory exists
        output_dir = os.path.dirname(output_file)
        if not os.path.exists(output_dir):
            os.makedirs(output_dir)  # Create output directory if it doesn't exist

        try:
            with open(output_file, 'w') as json_file:
                json.dump(data, json_file, indent=4)
            print(f"Parsed JSON saved to {output_file}")
        except Exception as e:
            print(f"Error saving JSON to file: {e}")

# Function to handle command-line arguments
def parse_arguments():
    """Parse command-line arguments."""
    parser = argparse.ArgumentParser(description="Parse a resume and generate a model response.")
    parser.add_argument("file_path", type=str, help="Path to the resume text file")
    parser.add_argument("output_file", type=str, help="Path to the output JSON file (in the output folder)")
    parser.add_argument("--prompt", type=str, help="Custom prompt to use with the model", default=None)
    return parser.parse_args()





# Main function to execute the steps
def main():
    # Parse command-line arguments
    args = parse_arguments()

    # Step 1: Initialize the parser class
    parser = ResumeParser()

    # Step 2: Read resume text from file
    resume_text = parser.read_resume_text(args.file_path)

    # Default prompt if none is provided
    default_prompt = [
        ("system", "What is the name,contact,work experiene,skills, of the candidate in given resume text ?"),
        ("human", resume_text),
        ("system", "Can you parse the given resume text in JSON format? NO PREAMBLE"),
        ("human", resume_text),
        ("system", "Ask some question regarding the experience person has ? NO PREAMBLE"),
        ("human", resume_text),
    ]

    # Step 3: Get the response from the model
    prompt = default_prompt if args.prompt is None else json.loads(args.prompt)
    response_content = parser.get_model_response(resume_text, prompt)

    # Step 4: Parse the response and save it to a JSON file
    parsed_response = parser.parse_response(response_content)
    if parsed_response:
        parser.save_json_to_file(parsed_response, args.output_file)
    else:
        print(f"Response content:\n{response_content}")

# if __name__ == "__main__":
#     main()
