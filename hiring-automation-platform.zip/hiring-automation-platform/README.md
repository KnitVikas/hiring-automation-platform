# Resume parser

This project extracts text from PDF, image, and Word document files using OCR and other text extraction techniques.

## Commands
- python -m venv venv
- source reader/bin/activate
- sudo apt-get install tesseract-ocr
- sudo apt-get install poppler-utils
- pip install -U langchain-community


## Features

- Extracts text from PDF files
- Extracts text from images using OCR (Tesseract)
- Extracts text from Word documents
- Added preprocessing steps for pdf


## Setup

Run the following command to install the required dependencies:

    pip install -r requirements.txt
    
## run
python src/main.py  "/data-mount2/dockreader/FileReader/Profile-abhishek.pdf"  --output_format txt

## run server command
uvicorn server:app --reload

## request your pdf using 
python request_server.py 

## docker commands

- sudo docker build -t myapp .
- docker run -p 8000:8000 myapp


 sudo chmod 777 -R .
 sudo apt-get install tesseract-ocr
 sudo apt-get install poppler-utils
 pip3 install -r requirements.txt