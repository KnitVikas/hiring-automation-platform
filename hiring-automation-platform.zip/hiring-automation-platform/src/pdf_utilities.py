from pdf2image import convert_from_path
import pytesseract
import os
import fitz  # PyMuPDF
import pikepdf

def extract_text_from_pdf(pdf_path):
    """Convert PDF to images and extract text using OCR."""
    pages = convert_from_path(pdf_path, 300)  # Convert PDF to images
    text = ""
    for page in pages:
        text += pytesseract.image_to_string(page)
    return text


def preprocess_pdf(pdf_path, max_size_mb=10, compressed_pdf_path=None):
    """
    Preprocess the PDF by checking its size and compressing if it's too large.
    
    Args:
    - pdf_path: The path to the input PDF file.
    - max_size_mb: The maximum allowed size in MB before compression is needed.
    - compressed_pdf_path: Optional path to save the compressed PDF.
    
    Returns:
    - The path of the PDF to use (either original or compressed).
    """
    # Check the size of the PDF
    pdf_size_mb = os.path.getsize(pdf_path) / (1024 * 1024)  # in MB
    print(f"PDF size: {pdf_size_mb:.2f} MB")
    
    # If the PDF is larger than the maximum size allowed, compress it
    if pdf_size_mb > max_size_mb:
        print(f"PDF is too large. Compressing...")
        
        # Use pikepdf to compress the PDF
        compressed_pdf_path = compressed_pdf_path or pdf_path.replace(".pdf", "_compressed.pdf")
        
        with pikepdf.open(pdf_path) as pdf:
            pdf.save(compressed_pdf_path, compress_streams=True)
        print(f"Compressed PDF saved to: {compressed_pdf_path}")
        return compressed_pdf_path  # Return the path to the compressed PDF
    
    return pdf_path  # Return the original PDF if no compression was needed

def extract_text_from_pdf(pdf_path, dpi=300):
    """Convert the PDF to images after preprocessing."""
    # Preprocess the PDF (check size and compress if needed)
    pdf_path_to_use = preprocess_pdf(pdf_path)
    
    # Convert the PDF to images
    print(f"Converting {pdf_path_to_use} to images with {dpi} DPI...")
    pages = convert_from_path(pdf_path_to_use, dpi=dpi)
    text = ""
    for page in pages:
        text += pytesseract.image_to_string(page)
    return text

# not using currently
def preprocess_image_for_ocr(image):
    """Apply preprocessing steps to the image before OCR."""
    image = convert_to_grayscale(image)
    image = remove_noise(image)
    image = binarize_image(image)
    image = deskew_image(image)
    image = enhance_contrast(image)
    return image

# # Example usage
# pdf_path = 'example.pdf'
# images = convert_pdf_to_images(pdf_path, dpi=300)
