from PIL import Image
import pytesseract
# pytesseract.pytesseract.tesseract_cmd = '/usr/local/bin/tesseract'  # Example for macOS
custom_config = r'--oem 3 --psm 6 --threads 4' 
def extract_text_with_pytesseract(image_path):
    """Extract text from an image using OCR."""
    img = Image.open(image_path)
    return pytesseract.image_to_string(img, config=custom_config)

# import easyocr
# from paddleocr import PaddleOCR
# def extract_text_with_easyocr(image_path, use_gpu=False):
#     """Extract text from an image using EasyOCR."""
#     reader = easyocr.Reader(['en'], gpu=use_gpu)
#     img = Image.open(image_path)
#     result = reader.readtext(image_path)
#     extracted_text = ' '.join([text[1] for text in result])
#     return extracted_text

# def extract_text_with_paddleocr(image_path, use_gpu=False):
#     """Extract text from an image using PaddleOCR."""
#     ocr = PaddleOCR(use_angle_cls=True, lang='en', gpu=use_gpu)
#     result = ocr.ocr(image_path, cls=True)
#     extracted_text = ' '.join([line[1][0] for line in result[0]])
#     return extracted_text
