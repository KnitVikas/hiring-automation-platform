from docx import Document

def extract_text_from_word(word_path):
    """Extract text from a Word document."""
    doc = Document(word_path)
    text = "\n".join([para.text for para in doc.paragraphs])
    return text