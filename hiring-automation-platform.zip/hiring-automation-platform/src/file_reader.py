from src.ocr_utilities import extract_text_with_pytesseract
import pytesseract
from pdf2image import convert_from_path
from PIL import Image
import os
import magic
from docx import Document
import json
import csv

class FileReader:
    def __init__(self, file_path, output_format="txt",ocr_name = "pytesseract"):
        self.file_path = file_path
        self.output_format = output_format
        self.file_type = self.get_file_type()  # Fix here, call method without file_path argument
        self.ocr_name = ocr_name

    def get_file_type(self):
        """Determine the MIME type of the file (image, PDF, or Word document)."""
        mime = magic.Magic(mime=True)
        return mime.from_file(self.file_path)  # The method works on instance (self), so no additional argument needed

    def pdf_to_text(self):
        """Extract text from a PDF file by converting pages to images and performing OCR."""
        from src.pdf_utilities import extract_text_from_pdf
        return extract_text_from_pdf(self.file_path)

    def image_to_text(self):
        """Extract text from an image using OCR."""
        
        if self.ocr_name =="pytesseract":
            return extract_text_with_pytesseract(self.file_path)
        # elif self.ocr_name =="easyocr":
        #     return extract_text_with_easyocr(image_path, use_gpu=False)
        # elif  self.ocr_name =="paddleocr":
        #     return extract_text_with_paddleocr(image_path, use_gpu=False)
        else:
            return "PLEASE CHOSE CORRECT OCR NAME."

    def word_to_text(self):
        """Extract text from a Word document."""
        from word_utilities import extract_text_from_word
        return extract_text_from_word(self.file_path)

    def write_to_file(self, extracted_text):
        """Write the extracted text to the specified file format."""
        output_filename = os.path.splitext(os.path.basename(self.file_path))[0] + "_extracted"
        output_path = os.path.join("extracted_text", f"{output_filename}.{self.output_format.lower()}")

        if self.output_format == "txt":
            with open(output_path, "w", encoding="utf-8") as f:
                f.write(extracted_text)

        elif self.output_format == "csv":
            with open(output_path, "w", newline='', encoding="utf-8") as file:
                writer = csv.writer(file)
                writer.writerow(["Extracted Text"])
                writer.writerow([extracted_text])

        elif self.output_format == "json":
            with open(output_path, "w", encoding="utf-8") as json_file:
                json.dump({"extracted_text": extracted_text}, json_file, ensure_ascii=False, indent=4)

    def read_file(self):
        """Read the file based on its type and extract text."""
        if "pdf" in self.file_type:
            return self.pdf_to_text()

        elif "image" in self.file_type:
            return self.image_to_text()

        elif "word" in self.file_type:
            return self.word_to_text()

        else:
            print(f"Unsupported file type: {self.file_type}")
            return None
