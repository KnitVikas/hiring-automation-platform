import os
import tempfile
import speech_recognition as sr
from typing import Dict, Any, Literal
from pydantic import BaseModel
from openai import OpenAI
from langchain_openai import ChatOpenAI
from langchain_core.prompts import ChatPromptTemplate
from langchain_core.output_parsers import JsonOutputParser

import numpy as np
from scipy.io import wavfile
import noisereduce as nr


# Response model
class AnalysisResult(BaseModel):
    clarity: Dict[str, Any]
    vocabulary: Dict[str, Any]
    fluency: Dict[str, Any]
    confidence: Dict[str, Any]
    relevance: Dict[str, Any]
    overall_summary: str

analysis_prompt = ChatPromptTemplate.from_template("""
Analyze this interview transcript and return JSON with:
{{
  "clarity": {{"score": int, "feedback": str}},
  "vocabulary": {{"score": int, "feedback": str}},
  "fluency": {{"score": int, "feedback": str}},
  "confidence": {{"score": int, "feedback": str}},
  "relevance": {{"score": int, "feedback": str}},
  "overall_summary": str
}}
Transcript: {text}
""")


import numpy as np
from scipy.io import wavfile
import noisereduce as nr

def clean_audio(audio_path: str) -> str:
    """Apply noise reduction and normalization"""
    # Read audio file
    rate, data = wavfile.read(audio_path)
    
    # Convert stereo to mono if needed
    if len(data.shape) > 1:
        data = np.mean(data, axis=1)
    
    # 1. Noise reduction (updated API)
    reduced_noise = nr.reduce_noise(
        data,
        rate,
        stationary=True,
        prop_decrease=0.75
    )
    
    # 2. Normalize volume
    peak = np.max(np.abs(reduced_noise))
    normalized = reduced_noise * (0.7 / peak)  # -3dB scaling
    
    # Save cleaned audio
    clean_path = audio_path.replace(".wav", "_clean.wav")
    wavfile.write(clean_path, rate, normalized.astype(np.int16))
    return clean_path

def normalize_volume(audio_data: np.ndarray) -> np.ndarray:
    """Normalize audio to -3dB peak volume"""
    peak = np.max(np.abs(audio_data))
    return audio_data * (0.7 / peak)  # -3dB scaling


def extract_audio(video_path: str) -> str:
    """Convert video to WAV using ffmpeg"""
    audio_path = os.path.join(tempfile.gettempdir(), "audio.wav")
    os.system(f"ffmpeg -i {video_path} -vn -acodec pcm_s16le -ar 16000 -ac 1 {audio_path} -y")
    return audio_path

def transcribe_google(audio_path: str) -> str:
    """Transcribe using Google Speech Recognition"""
    r = sr.Recognizer()
    with sr.AudioFile(audio_path) as source:
        audio = r.record(source)
        return r.recognize_google(audio)

def transcribe_whisper(audio_path: str) -> str:
    """Transcribe using OpenAI Whisper"""
    with open(audio_path, "rb") as audio_file:
        return client.audio.transcriptions.create(
            file=audio_file,
            model="whisper-1",
            response_format="text"
        )

def analyze_skills(text: str) -> Dict[str, Any]:
    """Analyze communication skills"""
    parser = JsonOutputParser(pydantic_object=AnalysisResult)
    chain = analysis_prompt | chat_model | parser
    return chain.invoke({"text": text})

def process_video(
    video_path: str,
    method: Literal["google", "whisper"] = "whisper"
) -> Dict[str, Any]:
    """Full pipeline: video -> audio -> text -> analysis"""
    # 1. Extract audio
    audio_path = extract_audio(video_path)
    clean_path = clean_audio(audio_path)
    
    # 2. Transcribe
    if method == "google":
        transcript = transcribe_google(clean_path)
    else:
        transcript = transcribe_whisper(clean_path)
    
    print(f"\nTranscript:\n{transcript}\n")
    
    # 3. Analyze
    analysis = analyze_skills(transcript)
    
    # Cleanup
    os.unlink(audio_path)
    return {
        "method": method,
        "transcript": transcript,
        "analysis": analysis
    }

if __name__ == "__main__":
    # Configuration
    os.environ["OPENAI_API_KEY"] = "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"
  # For Whisper
  # Initialize models
    client = OpenAI()  # For Whisper
    chat_model = ChatOpenAI(model="gpt-4", temperature=0.5)

    video_file = "speech.mp4"  # Change to your video path
    transcription_method = "google"  # or "whisper"
    
    if not os.path.exists(video_file):
        print(f"Error: File '{video_file}' not found!")
    else:
        result = process_video(video_file, method=transcription_method)
        
        # Print results
        print(f"\nAnalysis (using {result['method']}):")
        for skill in ["clarity", "vocabulary", "fluency", "confidence", "relevance"]:
            print(f"{skill.title()}: {result['analysis'][skill]['score']}/10 - {result['analysis'][skill]['feedback']}")
        print(f"\nOverall: {result['analysis']['overall_summary']}")