class JobPromptGenerator:
    def __init__(self, technology: str, company_name: str, timeframe: int = 30):
        self.technology = technology
        self.company_name = company_name
        self.timeframe = timeframe

    def generate_prompt(self) -> str:
        prompt = (
            f"Find recent job postings made by {self.company_name} for {self.technology} roles "
            f"in the last {self.timeframe} days. "
            "Include company name, job title, location, and posting date."
        )
        return prompt

# Example usage:
if __name__ == "__main__":

    from langchain_openai import ChatOpenAI
    from parser.chatgpt import interact_with_chatgpt


    generator = JobPromptGenerator(technology="Machine Learning", company_name="Google", timeframe=30)

    print("******************************",generator.generate_prompt())
    # generated_prompt = generator.generate_prompt()
    generated_prompt = "can you plz shareme the job posting by HCL in last 6 months"


    chatgpt_model = ChatOpenAI(model="gpt-4", temperature=0.2)
    response_content = interact_with_chatgpt(generated_prompt, chatgpt_model)
