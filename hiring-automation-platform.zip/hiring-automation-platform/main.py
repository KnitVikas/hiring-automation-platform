
import argparse
import logging
from parser.parser import ResumeParser
from src.file_reader import FileReader
import os
import openai
from langchain.chat_models import ChatOpenAI
from langchain.prompts import PromptTemplate
from langchain.chains import LLMChain
import logging.handlers  # Explicitly import the handlers module
from parser.chatgpt import interact_with_chatgpt
import warnings
import json
import re
from parser_prompt import ResumeParsingPrompt
from mcqQuest.question_creation_prompt import Prompt as quest_prompt
from coding_quest.codingQuestGen import CodeEvaluatorPromptGenerator 
from coding_quest.coding_problem_gen import CodingQuestionGenerator






def hide_warning():
    # Suppress LangChain specific deprecation warnings
    warnings.filterwarnings("ignore", category=DeprecationWarning, message=".LangChainDeprecationWarning.")
    # Alternatively, if you want to be more specific for the warnings you received:
    warnings.filterwarnings("ignore", category=UserWarning, message=".ChatOpenAI.")
    warnings.filterwarnings("ignore", category=UserWarning, message=".LLMChain.")
    warnings.filterwarnings("ignore", category=UserWarning, message=".Chain.run.")

def write_response_to_json(response_content, filename="response.json"):
    """
    Writes the response content to a JSON file.

    Args:
    response_content (dict or str): The content to be written into the JSON file.
    filename (str): The name of the file where the response will be saved.
    """
    try:
        # Open the file in write mode and dump the response content into it as JSON
        with open(filename, 'w') as json_file:
            json.dump(response_content, json_file, indent=4)
        logging.info(f"Response successfully written to {filename}")
    except Exception as e:
        logging.error(f"Error while writing to JSON file: {str(e)}")


# Configure logging functionality
def setup_logging(log_dir="logs", log_filename="text_extraction.log"):
    """
    Set up logging to both console and log file with rotation.

    Args:
    log_dir (str): Directory where the log files will be saved.
    log_filename (str): The name of the log file.
    """
    # Ensure the log directory exists
    if not os.path.exists(log_dir):
        os.makedirs(log_dir)

    # Define the log file path
    log_file_path = os.path.join(log_dir, log_filename)

    # Create a logger
    logger = logging.getLogger()

    # Set the log level
    logger.setLevel(logging.DEBUG)

    # Create a console handler with a log level of INFO
    console_handler = logging.StreamHandler()
    console_handler.setLevel(logging.INFO)

    # Create a file handler with a log level of DEBUG (for detailed logs)
    file_handler = logging.handlers.RotatingFileHandler(
        log_file_path, maxBytes=10 * 1024 * 1024, backupCount=3  # Max size: 10MB, keep 3 backups
    )
    file_handler.setLevel(logging.DEBUG)

    # Define the log format
    log_format = '%(asctime)s - %(levelname)s - %(message)s'
    formatter = logging.Formatter(log_format)

    # Add the formatter to the handlers
    console_handler.setFormatter(formatter)
    file_handler.setFormatter(formatter)

    # Add the handlers to the logger
    logger.addHandler(console_handler)
    logger.addHandler(file_handler)

    logging.info("Logging setup complete.")
def clean_output(response_content):
    # Sample string containing the JSON object


    # Use regular expression to extract the JSON object from the string
    match = re.search(r'\{.*\}', response_content, re.DOTALL)

    if match:
        json_data = json.loads(match.group())  # Convert the matched JSON string to a dictionary
        print(json_data)  # Output the extracted JSON data
    else:
        print("No JSON found in the string.")

    return json_data
    
def extract_and_process_resume(file_path, output_format="txt"):
    """
    Extracts text from a given resume file and processes it.

    Args:
    file_path (str): Path to the resume file.
    output_format (str): Format in which to save the extracted text. Default is "txt".
    
    Returns:
    str: Extracted text from the resume.
    """
    # Initialize the file reader
    file_reader = FileReader(file_path, output_format)

    # Read the file and extract text
    extracted_text = file_reader.read_file()

    if extracted_text:
        logging.info("Text extraction successful.")
        # Write extracted text to file
        file_reader.write_to_file(extracted_text)
        logging.info("Text successfully written to the output file.")
    else:
        logging.warning("No text extracted. The file might be empty or in an unsupported format.")

    return extracted_text

def parse_resume_with_model(prompt, model, parser):
    """
    Parses the extracted resume text using a pre-trained model and returns a response.

    Args:
    extracted_text (str): The extracted text from the resume.
    model: The pre-loaded model.

    Returns:
    dict: Parsed response from the model.
    """
    # Define the default prompt for the resume parsing task
    # default_prompt = [
    #     ("system", "What is the name, contact, work experience, skills of the candidate in the given resume text?"),
    #     ("human", extracted_text),
    #     ("system", "Can you parse the given resume text in JSON format? NO PREAMBLE"),
    #     ("human", extracted_text),
    #     ("system", "Ask some questions regarding the experience the person has? NO PREAMBLE"),
    #     ("human", extracted_text),
    # ]

    # Get the response from the model
    response_content = parser.get_model_response(prompt, model)
    print(response_content)

    return response_content



def main(file_path, parser_type):
    """
    Main function to execute resume extraction and parsing.

    Args:
    file_path (str): Path to the resume file.
    parser_type (str): Type of model parser ("resume" for the Llama model, "chatgpt" for ChatGPT).
    """
    # Extract text from the resume
    print("extracting....")
    extracted_text = extract_and_process_resume(file_path)
    print("extracted....")
    # If text is successfully extracted, parse the resume with the chosen model
    if extracted_text:
        if parser_type == "llama":
            # Initialize the resume parser with model configurations and load the model once
            parser = ResumeParser(model_name="llama-3.3-70b-versatile", temperature=0.0, max_retries=2)
            llama_model = parser.load_model()

            prompt_obj = ResumeParsingPrompt(extracted_text)
            prompt = prompt_obj.get_prompt()
            # print(" prompt : ",prompt )

            response_content = parse_resume_with_model(prompt, llama_model, parser)
            response_content =clean_output(response_content)
            logging.info(f"Model Response: {response_content}")
            write_response_to_json(response_content)

        elif parser_type == "chatgpt":
            chatgpt_model = ChatOpenAI(model="gpt-4", temperature=0.3)  # GPT-4 is the best model available
            logging.info("ChatGPT model loaded...")

            prompt_obj = ResumeParsingPrompt(extracted_text)
            prompt = prompt_obj.get_prompt()
            
            # prompt = f"Can you parse the given resume text in JSON format? NO PREAMBLE: {extracted_text}"
            response_content = interact_with_chatgpt(prompt, chatgpt_model)
            logging.info(f"ChatGPT Response: {response_content}")
            write_response_to_json(response_content)
        else:
            logging.error("Invalid parser type selected. Choose 'resume' or 'chatgpt'.")

def generate_mcq_question(quest_prompt,args):
    # If text is successfully extracted, parse the resume with the chosen model
    
    if args.parser_type == "llama":
        # Initialize the resume parser with model configurations and load the model once
        parser = ResumeParser(model_name="llama-3.3-70b-versatile", temperature=0.3, max_retries=2)
        llama_model = parser.load_model()

        # if len(prompt) == 2:
        response_content = llama_model.invoke(prompt)
        # response_content = clean_output(response_content.content)

        # response_content = parser.get_model_response(prompt, llama_model)
        print(response_content.content)
        logging.info(f"Model Response: {response_content.content}")
        # write_response_to_json(response_content)

    elif args.parser_type == "chatgpt":
        chatgpt_model = ChatOpenAI(model="gpt-4", temperature=0.3)  # GPT-4 is the best model available
        logging.info("ChatGPT model loaded...")
        print("ChatGPT model loaded...")
        
        response_content = interact_with_chatgpt(quest_prompt, chatgpt_model)
        print("ChatGPT Response: {response_content}")

        logging.info(f"ChatGPT Response: {response_content}")
        # write_response_to_json(response_content.json())
    else:
        logging.error("Invalid parser type selected. Choose 'resume' or 'chatgpt'.")

def eval_code(quest_prompt,args):
    # If text is successfully extracted, parse the resume with the chosen model
    
    if args.parser_type == "llama":
        # Initialize the resume parser with model configurations and load the model once
        parser = ResumeParser(model_name="llama-3.3-70b-versatile", temperature=0.3, max_retries=2)
        llama_model = parser.load_model()

        # if len(prompt) == 2:
        response_content = llama_model.invoke(prompt)
        # response_content = clean_output(response_content.content)

        # response_content = parser.get_model_response(prompt, llama_model)
        print(response_content.content)
        logging.info(f"Model Response: {response_content.content}")
        # write_response_to_json(response_content)

    elif args.parser_type == "chatgpt":
        chatgpt_model = ChatOpenAI(model="gpt-4", temperature=0.3)  # GPT-4 is the best model available
        logging.info("ChatGPT model loaded...")
        
        response_content = interact_with_chatgpt(quest_prompt,chatgpt_model)
        logging.info(f"ChatGPT Response: {response_content}")
        # write_response_to_json(response_content.json())
    else:
        logging.error("Invalid parser type selected. Choose 'resume' or 'chatgpt'.")

def generate_coding_question(quest_prompt,args):
    # If text is successfully extracted, parse the resume with the chosen model
    
    if args.parser_type == "llama":
        # Initialize the resume parser with model configurations and load the model once
        parser = ResumeParser(model_name="llama-3.3-70b-versatile", temperature=0.3, max_retries=2)
        llama_model = parser.load_model()

        # if len(prompt) == 2:
        response_content = llama_model.invoke(prompt)
        # response_content = clean_output(response_content.content)

        # response_content = parser.get_model_response(prompt, llama_model)
        print(response_content.content)
        logging.info(f"Model Response: {response_content.content}")
        # write_response_to_json(response_content)

    elif args.parser_type == "chatgpt":
        chatgpt_model = ChatOpenAI(model="gpt-4", temperature=0.3)  # GPT-4 is the best model available
        logging.info("ChatGPT model loaded...")
        print("ChatGPT model loaded...")


        
        response_content = interact_with_chatgpt(quest_prompt, chatgpt_model)
        print("ChatGPT Response: {response_content}")

        logging.info(f"ChatGPT Response: {response_content}")
        # write_response_to_json(response_content.json())
    else:
        logging.error("Invalid parser type selected. Choose 'resume' or 'chatgpt'.")



if __name__ == "__main__":  # Corrected this line
    # Set up logging before any logging actions occur
    # setup_logging()  # Uncomment if you have a setup function for logging

    print("starting")

    # Argument parsing for flexibility in file input and parser selection
    parser = argparse.ArgumentParser(description="Extract and parse resume data.")
    parser.add_argument("--file_path", default="/data-mount/PARSER/data/Profile-abhishek.pdf", type=str, help="Path to the resume PDF file.")
    parser.add_argument("--parser_type", default="chatgpt", choices=["llama", "chatgpt"], help="Select the model parser type.")
    args = parser.parse_args()

    quest_to_create = [{
        "techStack": "java",
        "expLevel": "beginner",
        "numOfQuestions": 5
    },
    {
        "techStack": "node js",
        "expLevel": "intermediate",
        "numOfQuestions": 5
    },
    {
        "techStack": "python",
        "expLevel": "advance",
        "numOfQuestions": 5
    }]


    prompt_obj = quest_prompt(quest_to_create)
    # prompt = p.get_json_output()


    prompt = prompt_obj.prompt
    print("this is prompt : ",prompt)
    # print("generation question : ",)
    # generate_question(prompt,args)
    # print("questions generated : ",)


    # evaluate coding questions
    code_to_evaluate = """
            def reverse_string(s):
                result = ""
                for char in s:
                    result = char + result
                return result
            """

    # prompt_generator = CodeEvaluatorPromptGenerator(code_to_evaluate)
    # # # Generate the prompt
    # prompt = prompt_generator.generate_prompt()
    # # print("this is prompt : ", prompt)
    # print("code ran successfully",eval_code(prompt,args))
    


    # try:
    # hide_warning()  # This is optional, use if needed
    # main(args.file_path, args.parser_type)
    # except Exception as e:
    #     logging.error(f"An error occurred: {str(e)}")
    input_data = [
        {
            "questionType": "coding",
            "expLevel": "medium",
            "noOfQuestion": 1,
        },
        {
            "questionType": "coding",
            "expLevel": "easy",
            "noOfQuestion": 1,
        }
    ]
    generator = CodingQuestionGenerator(input_data)
    generated_prompt = generator.generate_single_prompt()
    generate_coding_question(generated_prompt,args)