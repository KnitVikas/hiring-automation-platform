from fastapi import FastAPI, HTTPException, File, UploadFile, Form
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
from typing import Optional, Literal, Dict, Any, List
import os
import tempfile
import json
import logging
import logging.handlers
import re
import warnings
from io import BytesIO
from datetime import datetime

from selenium import webdriver
from selenium.webdriver.chrome.service import Service
# from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.chrome.options import Options
from selenium.common.exceptions import NoSuchElementException
from selenium.webdriver.chrome.service import Service
# from selenium.webdriver.support.ui import WebDriverWait
# from selenium.webdriver.support import expected_conditions as EC
from time import sleep
from random import randint
from webdriver_manager.chrome import ChromeDriverManager
from bs4 import BeautifulSoup
from typing import List, Optional

# External libraries
import docx
from PyPDF2 import PdfReader
import speech_recognition as sr
from openai import OpenAI
from pydantic import BaseModel

# LangChain imports
from langchain_openai import ChatOpenAI
from langchain_core.prompts import ChatPromptTemplate
from langchain_core.output_parsers import JsonOutputParser

# Local imports
from parser.parser import ResumeParser
from src.file_reader import FileReader
from parser.chatgpt import interact_with_chatgpt
#prompts
from prompts.parser_prompt import ResumeParsingPrompt
from prompts.question_creation_prompt import Prompt
from prompts.coding_based_on_tech import CodingQuestionGenerator
from prompts.eval_with_code import CodeEvaluatorPromptGenerator
from prompts.job_scraper import JobScrapingPromptBuilder
from prompts.company_tech import CompanyPromptGenerator
import ast
# Set up logging
import uvicorn
# Initialize FastAPI application
API_KEY = "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"
openai_api_key = API_KEY
app = FastAPI()
client = OpenAI()
# Add CORSMiddleware to handle CORS errors
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # You can change this to a list of specific domains for security
    allow_credentials=True,
    allow_methods=["*"],  # Allows all HTTP methods (GET, POST, PUT, DELETE, etc.)
    allow_headers=["*"],  # Allows all headers
)


# Set up logging
def setup_logging(log_dir="logs", log_filename="text_extraction.log"):
    if not os.path.exists(log_dir):
        os.makedirs(log_dir)

    log_file_path = os.path.join(log_dir, log_filename)
    logger = logging.getLogger()
    logger.setLevel(logging.DEBUG)

    console_handler = logging.StreamHandler()
    console_handler.setLevel(logging.INFO)

    file_handler = logging.handlers.RotatingFileHandler(
        log_file_path, maxBytes=10 * 1024 * 1024, backupCount=3
    )
    file_handler.setLevel(logging.DEBUG)

    log_format = '%(asctime)s - %(levelname)s - %(message)s'
    formatter = logging.Formatter(log_format)
    console_handler.setFormatter(formatter)
    file_handler.setFormatter(formatter)

    logger.addHandler(console_handler)
    logger.addHandler(file_handler)

    logging.info("Logging setup complete.")

# Suppress warnings
def hide_warning():
    warnings.filterwarnings("ignore", category=DeprecationWarning, message=".*LangChainDeprecationWarning.*")
    warnings.filterwarnings("ignore", category=UserWarning, message=".*ChatOpenAI.*")
    warnings.filterwarnings("ignore", category=UserWarning, message=".*LLMChain.*")
    warnings.filterwarnings("ignore", category=UserWarning, message=".*Chain.run.*")

# Function to extract text from various file types
def extract_text_from_file(file_contents, filename):
    try:
        if filename.lower().endswith('.pdf'):
            reader = PdfReader(BytesIO(file_contents))
            extracted_text = ""
            for page in reader.pages:
                extracted_text += page.extract_text()
            if extracted_text.strip():
                logging.info(f"Text extracted from PDF {filename}.")
                return extracted_text

        elif filename.lower().endswith('.docx'):
            doc = docx.Document(BytesIO(file_contents))
            extracted_text = ""
            for para in doc.paragraphs:
                extracted_text += para.text + "\n"
            if extracted_text.strip():
                logging.info(f"Text extracted from DOCX {filename}.")
                return extracted_text

        else:
            logging.error(f"Unsupported file type: {filename}")
            return None

    except Exception as e:
        logging.error(f"Error extracting text from {filename}: {str(e)}")
        return None

def parse_resume_with_model(prompt, model, parser):
    """Parses the extracted resume text using a pre-trained model and returns a response."""
    response_content =  parser.get_model_response(prompt, model)  # Awaiting async function
    return response_content

def load_models():
    global chatgpt_model

    chatgpt_model = ChatOpenAI(model="gpt-4", temperature=0.2)
    logging.info("All models loaded successfully.")

def clean_output(response_content):
    # Sample string containing the JSON object
    match = re.search(r'\{.*\}', response_content, re.DOTALL)

    if match:
        try:
            json_data = json.loads(match.group())
        except json.JSONDecodeError:
            json_data = ast.literal_eval(match.group())
        print(json_data)  # Output the extracted JSON data
    else:
        print("No JSON found in the string.")

    return json_data

# Load models when server starts
@app.on_event("startup")
def startup_event():
    hide_warning()
    setup_logging()
    load_models()  # Awaiting the model loading since it's async

@app.get("/")
async def root():
    """Root route to check if the server is running."""
    return {"message": "Welcome to the Resume Parser API! Use POST /parse_resume to parse resumes."}


@app.get("/health")
def health_check():
    return {"status": "ok"}


@app.post("/parse_resume/")
async def parse_resume(file: UploadFile = File(...), parser_type: str = "llama"):
    """API endpoint to upload and parse the resume."""
    
    # try:
    file_contents = await file.read()
    logging.info(f"Received file: {file.filename}, size: {len(file_contents)} bytes")
    
    # Extract text from the file
    extracted_text = extract_text_from_file(file_contents, file.filename)
    if not extracted_text:
        raise HTTPException(status_code=400, detail="No text extracted from resume.")

    response_content = {}

    if chatgpt_model:
        prompt_obj = ResumeParsingPrompt(extracted_text)
        prompt = prompt_obj.get_prompt()
        response_content =  interact_with_chatgpt(prompt, chatgpt_model)  # Await async chatgpt interaction
        response_content = clean_output(response_content)
        logging.info(f"ChatGPT Response: {response_content}")
    else:
        raise HTTPException(status_code=500, detail="ChatGPT model not loaded.")

    return JSONResponse(content=response_content)


# Define the model for each MCQ question, updated with correct field names
class McqQuestion(BaseModel):
    techStack: str
    expLevel: str
    numOfQuestions: int  # Change the field name to match the input

# Define the main request model
class McqSettingRequest(BaseModel):
    UploadCode: List[McqQuestion]  # A list of McqQuestion objects
    parser_type: str  # A string for parser type

# Post endpoint to receive MCQ questions
@app.post("/SetMcqQuestions/")
async def set_mcq_questions(request: McqSettingRequest):
    """API endpoint to upload and parse the MCQ questions."""
    
    # Printing the request data for debugging
    print("Request received:", request.dict())
    
    # Extracting UploadCode list from the request
    UploadQuest = request.UploadCode
    # Create a list of dictionaries for further processing if needed
    UploadQuest = [
        {"techStack": cls_obj.techStack, "expLevel": cls_obj.expLevel, "numOfQuestions": cls_obj.numOfQuestions}
        for cls_obj in UploadQuest
    ]
    
    # Extract parser type from the request
    parser_type = request.parser_type
    
    # Printing the final processed data for debugging
    print("Processed UploadQuest:", UploadQuest)
    print("Parser type:", parser_type)

    print("UploadQuest", UploadQuest)
    # try:
        # Check if the input is provided, if not, raise an exception
    if UploadQuest is None:
        raise HTTPException(status_code=400, detail="No questions data provided.")

    quest_to_create = UploadQuest  # Use the input directly
    logging.info(f"Received quest data: {quest_to_create}")
    
    response_content = {}

    chatgpt_model = ChatOpenAI(model="gpt-3.5-turbo", temperature=0.3)
    if chatgpt_model:
        # try:
            print("chatgpt model is loaded")
            # Generate prompt using the quest_to_create data
            
            prompt_obj = Prompt(UploadQuest)
            print("tthis is final prompt",prompt_obj)
            prompt = prompt_obj.prompt
            print("tthis is final prompt",prompt)
            response_content = interact_with_chatgpt(prompt, chatgpt_model)
            response_content = json.loads(response_content)

    return JSONResponse(content=response_content)


# Define a model for each individual coding question
class CodingQuestion(BaseModel):
    questionType: str
    expLevel: str
    noOfQuestion: int
    tech: str

# Define the main request model
class CodeSettingRequest(BaseModel):
    UploadCode: List[CodingQuestion]
    parser_type: str

@app.post("/SetCodingQuestions/")
async def set_coding_questions(request: CodeSettingRequest):
    UploadQuest = request.UploadCode
    parser_type = request.parser_type

    try:
        # ❌ Fix: You wrote `questions` instead of `UploadQuest`
        if not UploadQuest:
            raise HTTPException(status_code=400, detail="No questions data provided.")

        # ✅ No need to convert CodingQuestion objects to dicts manually if you already have list of Pydantic models,
        # but if required downstream, then we can transform it:
        formatted_questions = [
            {
                "questionType": q.questionType,
                "expLevel": q.expLevel,
                "noOfQuestion": q.noOfQuestion,
                "tech": q.tech
            }
            for q in UploadQuest
        ]

        logging.info(f"Received quest data: {formatted_questions}")
        print("UploadQuest", formatted_questions, parser_type)

        response_content = {}
        if chatgpt_model:
            generator = CodingQuestionGenerator(formatted_questions)
            generated_prompt = generator.generate_single_prompt()
            print("Generated Prompt:", generated_prompt)
            response_content = interact_with_chatgpt(generated_prompt, chatgpt_model)
            response_content = clean_output(response_content)
            logging.info(f"ChatGPT Response: {response_content}")
        else:
            raise HTTPException(status_code=500, detail="ChatGPT model not loaded.")

        return JSONResponse(content=response_content)

    except Exception as e:
        logging.error(f"An error occurred: {str(e)}")
        raise HTTPException(status_code=500, detail="An error occurred while processing the request.")


class CodeSolution(BaseModel):
    answer: str
    question: str

class CodeEvaluationRequest(BaseModel):
    UploadCode: List[CodeSolution]  # Changed from string to list of code solutions
    parser_type: str


@app.post("/evaluateCode/")
async def eval_code(request_data: CodeEvaluationRequest):
    """API endpoint to evaluate code solutions."""
    
    # Convert Pydantic model to dict for the prompt generator
    input_data = {
        "uploadedCode": [{"answer": item.answer, "question": item.question} for item in request_data.UploadCode],
        "parser_type": request_data.parser_type
    }

    print("Received UploadCode:", input_data)  # Log incoming data

    try:
        if not input_data["uploadedCode"]:
            raise HTTPException(status_code=400, detail="No code provided.")

        logging.info(f"Received code evaluation data: {input_data}")
        
        response_content = {}

    
        if chatgpt_model:
            try:
                generator = CodeEvaluatorPromptGenerator(input_data)
                combined_prompt = generator.generate_combined_prompt()
                print("prompt : ", combined_prompt)
                response_content = interact_with_chatgpt(combined_prompt["evaluation_prompt"], chatgpt_model)
                response_content = clean_output(response_content)
                # print("Evaluation response:", response_content.content)
                logging.info(f"ChatGPT Response: {response_content}")
            except Exception as e: 
                logging.error(f"Error in ChatGPT evaluation: {str(e)}")
                raise HTTPException(status_code=500, detail="Error in code evaluation")
        else:
            raise HTTPException(status_code=500, detail="ChatGPT model not loaded.")


        return JSONResponse(content=response_content)

    except Exception as e:
        logging.error(f"An error occurred: {str(e)}")
        raise HTTPException(status_code=500, detail="An error occurred while processing the request.")



#################################### scrabe job posting from job portals ##############################

# Pydantic models to validate the request data


class JobScrapingRequest(BaseModel):
    country: str = "India"
    platforms: Optional[List[str]] = ["Naukri.com", "LinkedIn Jobs", "Indeed", "Monster India"]
    locations: Optional[List[str]] = ["Bangalore", "Hyderabad", "Pune", "Delhi"]
    skills: Optional[List[str]] = ["Java", "Python", "AWS", "React", "Node.js"]
    companies: Optional[List[str]] = ["TCS", "Infosys", "Google", "Amazon", "Wipro"]
    posted_within_days: int = 60  # Defaulting to 60 days (can be adjusted)



# FastAPI endpoint to generate the prompt based on the input data
@app.post("/generateJobScrapingPrompt/")
async def generate_job_scraping_prompt(request_data: JobScrapingRequest):
    """API endpoint to generate the job scraping prompt."""
    
   # Convert the Pydantic model to the required data structure
    input_data = {
        "country": request_data.country,
        "platforms": request_data.platforms,
        "locations": request_data.locations,
        "skills": request_data.skills,
        "companies": request_data.companies,
        "posted_within": request_data.posted_within_days
    }

    print("Received Job Scraping Request:", input_data)  # Log incoming data

    # try:
        # Initialize the JobScrapingPromptBuilder with the provided data
    prompt_builder = JobScrapingPromptBuilder(
        country=input_data["country"],
        platforms=input_data["platforms"],
        locations=input_data["locations"],
        skills=input_data["skills"],
        companies=input_data["companies"],
        posted_within=f"last {request_data.posted_within_days} days"
    )

    # Generate the scraping prompt
    generated_prompt = prompt_builder.generate_prompt()


    if chatgpt_model:
        # try:
            response_content = interact_with_chatgpt(generated_prompt, chatgpt_model)
            print("response_content", response_content)
            # response_content = clean_output(response_content)
            logging.info(f"ChatGPT Response: {response_content}")
    #     except Exception as e: 
    #         logging.error(f"Error in ChatGPT evaluation: {str(e)}")
    #         raise HTTPException(status_code=500, detail="Error in code evaluation")
    # else:
    #     raise HTTPException(status_code=500, detail="ChatGPT model not loaded.")

    return JSONResponse(content=response_content)

############################################ company tech stack roles ############################################

class CompanyPromptRequest(BaseModel):
    companies: List[str]

@app.post("/companyTechstack/")
async def generate_company_prompt(request_data: CompanyPromptRequest):
    """API endpoint to generate company hiring prompt and get the skills data."""

    input_data = {
        "companies": request_data.companies
    }

    print("Received Company Prompt Request:", input_data)

    try:
        if not input_data["companies"]:
            raise HTTPException(status_code=400, detail="No companies provided.")

        # Build the prompt
        prompt_builder = CompanyPromptGenerator(companies=input_data["companies"])
        generated_prompt = prompt_builder.generate_prompt()

        # Interact with chatgpt
        if chatgpt_model:
            response_content = interact_with_chatgpt(generated_prompt, chatgpt_model)
            response_content = json.loads(response_content)
            print("ChatGPT Response:", response_content)
            logging.info(f"ChatGPT Response: {response_content}")
        else:
            raise HTTPException(status_code=500, detail="ChatGPT model not loaded.")

        return JSONResponse(content=response_content)

    except Exception as e:
        logging.error(f"An error occurred while generating the company prompt: {str(e)}")
        raise HTTPException(status_code=500, detail="An error occurred while processing the request.")

############################3 scrape job postings from job portals ##############################


start_time = datetime.now()
print('Crawl starting time : {}' .format(start_time.time()))
def get_driver():
    options = webdriver.ChromeOptions() 
    options.headless = True
    chrome_driver_path = '/home/vikas/.wdm/drivers/chromedriver/linux64/134.0.6998.165/chromedriver-linux64/chromedriver'  # Update with your ChromeDriver path
    driver = webdriver.Chrome(service=Service(chrome_driver_path), options=options)
    return driver

def generate_url(index):
    if index == 1:
        return "https://www.naukri.com/software-engineer-jobs-in-india"
        # return "https://www.naukri.com/hcl-jobs"
    else:
        return format("https://www.naukri.com/machine-learning-engineer-jobs-in-india-{}".format(index))
    return url

def extract_rating(rating_a):
    if rating_a is None or rating_a.find('span', class_="main-2") is None:
        return "None"
    else:
        return rating_a.find('span', class_="main-2").text
  
class ScrapeRequest(BaseModel):
    company_name: Optional[str] = None
    location: Optional[str] = None
    skill: Optional[str] = None
    designation: Optional[str] = None
    start_page: int = 1
    end_page: int = 20

# ---------- API Endpoint ----------

def parse_job_data_from_soup(page_jobs):
    all_jobs = []
    for job in page_jobs:
        job_details = {"job_title": None, "company_name": None, "rating": None, "experience": None, "location": None, "min_requirements": None, "all_tech_stack": []}
        
        job = BeautifulSoup(str(job), 'html.parser')
        row1 = job.find('div', class_="row1")
        row2 = job.find('div', class_="row2")
        row3 = job.find('div', class_="row3")
        row4 = job.find('div', class_="row4")
        row5 = job.find('div', class_="row5")
        row6 = job.find('div', class_="row6")
        
        job_title = row1.a.text
        company_name = row2.span.a.text
        rating_a = row2.span
        rating = extract_rating(rating_a)
        
        job_details = row3.find('div', class_="job-details")
        ex_wrap = job_details.find('span', class_="exp-wrap").span.span.text
        location = job_details.find('span', class_="loc-wrap ver-line").span.span.text

        min_requirements = row4.span.text

        all_tech_stack = []
        if row5:
            ul_tag = row5.find('ul')
            if ul_tag:
                for tech_stack in ul_tag.find_all('li', class_=["dot-gt", "tag-li"]):
                    all_tech_stack.append(tech_stack.text.strip())

        posted_time = None
        if row6:
            posted_time_span = row6.find('span', class_="Posted")
            if posted_time_span:
                posted_time = posted_time_span.text.strip()
        
        job_details = {
            "job_title": job_title,
            "company_name": company_name,
            "rating": rating,
            "experience": ex_wrap,
            "location": location,
            "min_requirements": min_requirements,
            "all_tech_stack": all_tech_stack,
            "posted_time": posted_time
        }
        all_jobs.append(job_details)

    return all_jobs

@app.post("/scrape_jobs")
def scrape_jobs(request: ScrapeRequest):
    driver = get_driver()
    flag_url = False
    all_jobs = []

    company_name = request.company_name
    location = request.location
    skill = request.skill
    designation = request.designation
    start_page = request.start_page
    end_page = request.end_page

    if company_name:
        if location:
            base_url = f"https://www.naukri.com/{company_name}-jobs-in-{location}-page-"
        else:
            location = "india"
            base_url = f"https://www.naukri.com/{company_name}-jobs-in-{location}-page-"
    elif skill:
        if location:
            base_url = f"https://www.naukri.com/{skill}-jobs-in-{location}-page-"
        else:
            location = "india"
            base_url = f"https://www.naukri.com/{skill}-jobs-in-{location}-page-"
    elif designation:
        if location:
            base_url = f"https://www.naukri.com/{designation}-jobs-in-{location}-page-"
        else:
            location = "india"
            base_url = f"https://www.naukri.com/{designation}-jobs-in-{location}-page-"
    else:
        base_url = "https://www.naukri.com"
        flag_url = True

    try:
        if flag_url:
            for i in range(start_page, end_page):
                url = f"{base_url}{i}"
                driver.get(url)
                sleep(randint(5, 10))
                page_source = driver.page_source
                soup = BeautifulSoup(page_source, 'html.parser')
                page_soup = soup.find_all("div", class_="srp-jobtuple-wrapper")
                jobs = parse_job_data_from_soup(page_soup)
                all_jobs.extend(jobs)
        else:
            for i in range(start_page, end_page):
                final_url = base_url + str(i)
                driver.get(final_url)
                sleep(randint(5, 10))
                page_source = driver.page_source
                soup = BeautifulSoup(page_source, 'html.parser')
                page_soup = soup.find_all("div", class_="srp-jobtuple-wrapper")
                jobs = parse_job_data_from_soup(page_soup)
                all_jobs.extend(jobs)
        
    except Exception as e:
        return {"error": str(e)}
    finally:
        driver.quit()

    return {"jobs": all_jobs}

# ------------------------------------------------------------------------------------------------------------------------------------?


#####################################     Behavoural Analysis code #########################################3
# Define response model
class AnalysisResult(BaseModel):
    clarity: Dict[str, Any]
    vocabulary: Dict[str, Any]
    fluency: Dict[str, Any]
    confidence: Dict[str, Any]
    relevance: Dict[str, Any]
    overall_summary: str

# Communication skills analysis prompt# Updated communication skills analysis prompt
analysis_prompt = ChatPromptTemplate.from_template("""
Analyze this interview transcript for communication skills and return a JSON object with the following structure:
{{
  "clarity": {{"score": int, "feedback": str}},
  "vocabulary": {{"score": int, "feedback": str}},
  "fluency": {{"score": int, "feedback": str}},
  "confidence": {{"score": int, "feedback": str}},
  "relevance": {{"score": int, "feedback": str}},
  "overall_summary": str
}}

Evaluation Criteria:
1. Clarity (1-10) - Clear articulation of thoughts
2. Vocabulary (1-10) - Word choice and language proficiency
3. Fluency (1-10) - Speech flow and hesitation
4. Confidence (1-10) - Tone and self-assurance
5. Relevance (1-10) - Answer appropriateness

Important:
- Return ONLY valid JSON
- Scores must be integers between 1-10
- Do not include any explanatory text outside the JSON

Transcript: {text}
""")
def extract_audio(video_path: str) -> str:
    """Convert video to WAV audio using ffmpeg"""
    audio_path = os.path.join(tempfile.gettempdir(), "extracted_audio.wav")
    os.system(f"ffmpeg -i {video_path} -vn -acodec pcm_s16le -ar 16000 -ac 1 {audio_path} -y")
    return audio_path

def transcribe_google(audio_path: str) -> str:
    """Transcribe using Google Speech Recognition"""
    recognizer = sr.Recognizer()
    with sr.AudioFile(audio_path) as source:
        audio = recognizer.record(source)
        return recognizer.recognize_google(audio)

async def transcribe_whisper(audio_path: str, api_key: str) -> str:
    """Transcribe using OpenAI Whisper"""
    client.api_key = api_key
    with open(audio_path, "rb") as audio_file:
        transcript = client.audio.transcriptions.create(
            file=audio_file,
            model="whisper-1",
            response_format="text"
        )
    return transcript

def analyze_skills(text: str) -> Dict[str, Any]:
    """Analyze communication skills using ChatGPT"""
    parser = JsonOutputParser(pydantic_object=AnalysisResult)
    chain = analysis_prompt | chatgpt_model | parser
    return chain.invoke({"text": text})

@app.post("/analyze_interview/")
async def analyze_interview(
    video: UploadFile = File(...),
    transcribe_method: Literal["google", "whisper"] = Form("google"),
    
):
    try:
         # For Whisper transcription
        # Save video temporarily
        with tempfile.NamedTemporaryFile(delete=False, suffix=".mp4") as tmp_video:
            tmp_video.write(await video.read())
            video_path = tmp_video.name
        
        # Extract audio
        audio_path = extract_audio(video_path)
        
        # Transcribe using selected method
        if transcribe_method == "google":
            transcript = transcribe_google(audio_path)
        elif transcribe_method == "whisper":
            if not openai_api_key:
                raise HTTPException(400, "OpenAI API key is required for Whisper")
            transcript = await transcribe_whisper(audio_path, openai_api_key)
        else:
            raise HTTPException(400, "Invalid transcription method")
        
        # Analyze communication skills
        analysis = analyze_skills(transcript)
        
        # Cleanup
        os.unlink(video_path)
        os.unlink(audio_path)
        
        return {
            "transcription_method": transcribe_method,
            "transcript": transcript,
            "analysis": analysis
        }
        
    except sr.UnknownValueError:
        raise HTTPException(400, "Audio not understandable")
    except sr.RequestError:
        raise HTTPException(503, "Speech service unavailable")
    except json.JSONDecodeError:
        raise HTTPException(500, "Failed to parse analysis results")
    except Exception as e:
        raise HTTPException(500, str(e))
# if __name__ == "__main__":
#     uvicorn.run(
#         "server:app",  # Replace with your actual file name
#         host=".0.0.0",
#         port=443,  # Default HTTPS port
#         ssl_keyfile="key.pem",
#         ssl_certfile="cert.pem",
#         log_level="info"
#     )